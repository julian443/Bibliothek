package ch.aprentas.praesentationsschicht;

public class Starter {

    public static void main(String[] args) throws Exception {
        Konsole konsole = new Konsole();
        konsole.startProgram();
    }

}
