package ch.aprentas.datenschicht;

public class MediumDAO {
}
